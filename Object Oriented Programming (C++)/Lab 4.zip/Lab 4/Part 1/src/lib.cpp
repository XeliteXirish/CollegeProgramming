#include "lib.h"
#include <iostream>

int foo;
void print_foo()
{
    std::cout << foo << std::endl;
}

void print(int i)
{
    std::cout << i << std::endl;
}
