#include "lib.h"

int main() {
    foo = 7;
    print_foo();

    print(99);
    return 0;
}
